%%%-------------------------------------------------------------------
%%% @author User
%%% @copyright (C) 2022, <COMPANY>
%%% @doc
%%%
%%% @end
%%% Created : 20. Oct 2022 3:06 PM
%%%-------------------------------------------------------------------
-module(scratchpad).
-author("User").

%% API
-export([main/0]).

main() ->
%%  crypto:sha(integer_to_binary(123)).
  Abc = 1,
  Def = 2,
  NodesList = [3,4],
  [7|NodesList].

